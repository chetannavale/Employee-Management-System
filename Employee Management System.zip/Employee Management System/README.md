# Angular-10-Spring-Boot-CRUD-Full-Stack-App
Angular Spring Boot CRUD Full Stack App created for my YouTube course

### Angular 10 + Spring Boot CRUD Full Stack App - 1 - Project Overview
=> https://youtu.be/tLBX9fq813c

### Angular 10 + Spring Boot CRUD Full Stack App - 2 - Project Architecture and Development Process
=> https://youtu.be/Uvy0CsBxdms

### Angular 10 + Spring Boot CRUD Full Stack App - 3 - Create Spring Boot Project and Configure MySQL
=> https://youtu.be/kpM5xV17S9U

### Angular 10 + Spring Boot CRUD Full Stack App - 4 - Creating JPA Entity + Repository
=> https://youtu.be/PKt3Yr8mi5g

### Angular 10 + Spring Boot CRUD Full Stack App - 5 - Creating List Employee REST API
=> https://youtu.be/RA37EdWywjg

### Angular 10 + Spring Boot CRUD Full Stack App - 6 - Creating Angular App using Angular CLI
=> https://youtu.be/ItRmRKaIwlo

### Angular 10 + Spring Boot CRUD Full Stack App - 7 - Exploring Angular CLI Project Structure
=> https://youtu.be/-FClmrfQBPw

### Angular 10 + Spring Boot CRUD Full Stack App - 8 - Angular App Components Overview
=> https://youtu.be/1V4j7RESNK4

### Angular 10 + Spring Boot CRUD Full Stack App - 9 - Add Bootstrap 4 in Angular App
=> https://youtu.be/PraK-poGy84

### Angular 10 + Spring Boot CRUD Full Stack App - 10 - Creating Angular Employee List Component
=> https://youtu.be/wrb0_b4A0Xo

### Angular 10 + Spring Boot CRUD Full Stack App - 11 - Connecting Angular with List Employee REST API
=> https://youtu.be/poQLnZU0eHc

### Angular 10 + Spring Boot CRUD Full Stack App - 11 - Connecting Angular with List Employee REST API
=> https://youtu.be/poQLnZU0eHc

### Angular 10 + Spring Boot CRUD Full Stack App - 12 - Routing and Navigation in Angular App
=> https://youtu.be/TUYyW0l8fiA

### Angular 10 + Spring Boot CRUD Full Stack App - 13 - Creating Add Employee REST API
=> https://youtu.be/qH7_1W8MKfs

### Angular 10 + Spring Boot CRUD Full Stack App - 14 - Creating Angular Create Employee Component
=> https://youtu.be/yYlMsNdAXJ4
### Angular 10 + Spring Boot CRUD Full Stack App - 15 - Angular Create Employee Form Handling
=> https://youtu.be/RTCRYdF7FBA

### Angular 10 + Spring Boot CRUD Full Stack App - 16 - Connecting Angular with Create Employee REST API
=> https://youtu.be/bh-HDtx-ppw

### Angular 10 + Spring Boot CRUD Full Stack App - 17 - Creating REST API to Get Single Employee Object
=> https://youtu.be/F2SIletJ7jc
### Angular 10 + Spring Boot CRUD Full Stack App - 18 - Creating Update Employee REST API
=> https://youtu.be/XG3cgNvVx9M

### Angular 10 + Spring Boot CRUD Full Stack App - 19 - Create Angular Update Employee Component & Form
=> https://youtu.be/Hog4sRXnsCE

### Angular 10 + Spring Boot CRUD Full Stack App - 20 - Connecting Angular with Get Employee REST API
=> https://youtu.be/S4Q5yOxCnIY

### Angular 10 + Spring Boot CRUD Full Stack App - 21 - Connecting Angular with Update Employee REST API
=> https://youtu.be/-Kz0hsW2k68
### Angular 10 + Spring Boot CRUD Full Stack App - 22 - Creating DELETE REST API to Delete an Employee
=> https://youtu.be/B8CF7IaevYk

### Angular 10 + Spring Boot CRUD Full Stack App - 23 - Connecting Angular with Delete Employee REST API
=> https://youtu.be/gS_2aVA0H3A

### Angular 10 + Spring Boot CRUD Full Stack App - 24 - Creating View Employee Details Functionality
=> https://youtu.be/eAXhAAyZu7U

### Angular 10 + Spring Boot CRUD Full Stack App - 25 - It's Demo Time and Source Code on GitHub
=> https://youtu.be/m3_dJSqkFzU
